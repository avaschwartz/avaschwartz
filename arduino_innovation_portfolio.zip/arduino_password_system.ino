/*
  Summative Arduino Extension
  Keypad + Piezo Buzzer + Green/Red LEDs + Changeable Password + Fan

  NOTE:
  This is a starter/reference sketch based on the features described in the journal.
  Adjust the keypad pin assignments and fan/transistor pin to match your actual wiring.
*/

#include <Keypad.h>

const byte ROWS = 4;
const byte COLS = 4;

char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};

// Change these to match your actual keypad wiring.
byte rowPins[ROWS] = {2, 3, 4, 5};
byte colPins[COLS] = {6, 7, 8, 9};

Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

const int BUZZER_PIN = 10;
const int GREEN_LED_PIN = 11;
const int RED_LED_PIN = 12;

// Connect this pin to the base/gate control of your transistor/MOSFET.
// Do NOT power a fan directly from an Arduino I/O pin.
const int FAN_PIN = 13;

String password = "1234";
String entered = "";

enum Mode {
  NORMAL,
  VERIFY_OLD,
  NEW_PASSWORD_1,
  NEW_PASSWORD_2
};

Mode mode = NORMAL;
String pendingPassword = "";

void setup() {
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(GREEN_LED_PIN, OUTPUT);
  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(FAN_PIN, OUTPUT);

  digitalWrite(GREEN_LED_PIN, LOW);
  digitalWrite(RED_LED_PIN, LOW);
  digitalWrite(FAN_PIN, LOW);

  Serial.begin(9600);
  Serial.println("Arduino password system ready.");
}

void beep() {
  tone(BUZZER_PIN, 1000, 80);
}

void clearInput() {
  entered = "";
  digitalWrite(GREEN_LED_PIN, LOW);
  digitalWrite(RED_LED_PIN, LOW);
}

void checkNormalPassword() {
  if (entered == password) {
    digitalWrite(GREEN_LED_PIN, HIGH);
    digitalWrite(RED_LED_PIN, LOW);
    digitalWrite(FAN_PIN, HIGH);
    Serial.println("Correct password.");
  } else {
    digitalWrite(GREEN_LED_PIN, LOW);
    digitalWrite(RED_LED_PIN, HIGH);
    digitalWrite(FAN_PIN, LOW);
    Serial.println("Incorrect password.");
  }

  entered = "";
}

void handleNormalKey(char key) {
  if (key == '*') {
    clearInput();
    Serial.println("Input cleared.");
  } else if (key == '#') {
    checkNormalPassword();
  } else if (key == 'A') {
    entered = "";
    mode = VERIFY_OLD;
    Serial.println("Password change: enter current password, then #.");
  } else {
    entered += key;
  }
}

void handleChangeKey(char key) {
  if (key == '*') {
    entered = "";
    mode = NORMAL;
    Serial.println("Password change cancelled.");
    return;
  }

  if (mode == VERIFY_OLD) {
    if (key == '#') {
      if (entered == password) {
        entered = "";
        mode = NEW_PASSWORD_1;
        Serial.println("Current password correct. Enter new password, then #.");
      } else {
        entered = "";
        mode = NORMAL;
        Serial.println("Current password incorrect.");
      }
    } else {
      entered += key;
    }
  }
  else if (mode == NEW_PASSWORD_1) {
    if (key == '#') {
      if (entered.length() > 0) {
        pendingPassword = entered;
        entered = "";
        mode = NEW_PASSWORD_2;
        Serial.println("Enter the new password again, then #.");
      }
    } else {
      entered += key;
    }
  }
  else if (mode == NEW_PASSWORD_2) {
    if (key == '#') {
      if (entered == pendingPassword) {
        password = pendingPassword;
        Serial.println("Password changed successfully.");
      } else {
        Serial.println("Passwords did not match.");
      }

      entered = "";
      pendingPassword = "";
      mode = NORMAL;
    } else {
      entered += key;
    }
  }
}

void loop() {
  char key = keypad.getKey();

  if (key) {
    beep();
    Serial.print("Key: ");
    Serial.println(key);

    if (mode == NORMAL) {
      handleNormalKey(key);
    } else {
      handleChangeKey(key);
    }
  }
}
