# Arduino Innovation Portfolio

A GitHub Pages portfolio for my Tech & Innovation Innovator Journal.

## Pages
- `index.html` — Home page
- `about.html` — About Me
- `projects.html` — Project journal
- `arduino_password_system.ino` — Arduino sketch
- `images/` — Project photos and video

## GitHub Pages
1. Create a GitHub repository (for example, `arduino-portfolio`).
2. Upload all of the files and folders in this ZIP.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`, then save.
6. GitHub will provide the website URL after it publishes.

## Before submitting
Replace the peer-support placeholder in `projects.html` with a real moment from class.
