Put your actual project files here with these exact names:
IMG_4491.jpeg
IMG_4507.jpeg
My Movie 1.mp4
